# Phishing Detection Using Machine Learning Techniques

Implementation for different machine learning classification methods for detection phishing websites.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip3 install -r requirments.txt
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## Authors and acknowledgment
- Vahid Shahrivari
- Mohammad Mahdi Darabi

Thanks from philomathic-guy for writing feature_extractor.py

## Contact
- Vahid Shahrivari v.shahrivari@gmail.com

## License
[MIT](https://choosealicense.com/licenses/mit/)